import { GoogleGenAI } from "@google/genai";
import { ProjectMetrics, YearlyData } from "../types";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found");
  }
  return new GoogleGenAI({ apiKey });
};

export const analyzeProjectFinancials = async (
  metrics: ProjectMetrics,
  tableData: YearlyData[]
): Promise<string> => {
  const ai = getClient();
  
  const prompt = `
    تو یک مشاور مالی بسیار باهوش، شوخ‌طبع، کمی کنایه‌زن و "خودمانی" هستی.
    قرار است یک تحلیل برای پروژه سرمایه‌گذاری زیر ارائه دهی.
    لطفاً خشک و رسمی صحبت نکن! از اصطلاحات عامیانه و بامزه فارسی استفاده کن. مثل یک دوست صمیمی که دارد با شوخی نصیحت می‌کند.
    
    داده‌های پروژه:
    - سرمایه اولیه که وسط گذاشتیم: ${metrics.initialInvestment} (واحد پول)
    - نرخ تنزیل (توقع ما از سود): ${metrics.discountRate * 100}%
    - NPV (سود خالص فعلی): ${metrics.npv.toFixed(2)}
    - IRR (بازده داخلی): ${metrics.irr.toFixed(2)}%
    
    پول‌هایی که قراره بیاد (جریان نقدی):
    ${tableData.map(d => `سال ${d.year}: ${d.cashFlow}`).join('\n')}
    
    لطفاً تحلیل خود را در قالب Markdown و با ساختار زیر بنویس:
    1. **نظر کلی (با لحن طنز)**: (مثلاً اگه خوبه بگو "ایول داری!"، اگه بده بگو "پولتو آتیش نزن!")
    2. **ریسک ماجرا**: (با مقایسه IRR و نرخ تنزیل، ولی به زبان ساده و خنده‌دار)
    3. **حرف آخر**: (انجام بدیم یا فرار کنیم؟)
    
    حتماً از ایموجی‌های بامزه استفاده کن.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 0 }
      }
    });

    return response.text || "خطا در دریافت پاسخ از مدل.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "متاسفانه مغز هوش مصنوعی هنگ کرد! شاید قهوه‌اش کم شده. دوباره تلاش کن.";
  }
};