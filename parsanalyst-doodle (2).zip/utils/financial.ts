import { YearlyData } from '../types';

export const calculatePV = (cashFlow: number, rate: number, year: number): number => {
  return cashFlow / Math.pow(1 + rate, year);
};

export const calculateFV = (cashFlow: number, rate: number, yearsUntilEnd: number): number => {
  return cashFlow * Math.pow(1 + rate, yearsUntilEnd);
};

export const calculateNPV = (initialInvestment: number, cashFlows: number[], rate: number): number => {
  let npv = initialInvestment; // Usually negative
  cashFlows.forEach((cf, index) => {
    npv += calculatePV(cf, rate, index + 1);
  });
  return npv;
};

// Newton-Raphson method for IRR
export const calculateIRR = (initialInvestment: number, cashFlows: number[]): number => {
  let guess = 0.1;
  const maxIterations = 1000;
  const precision = 0.00001;

  for (let i = 0; i < maxIterations; i++) {
    let npv = initialInvestment;
    let derivativeNpv = 0;

    for (let t = 0; t < cashFlows.length; t++) {
      const year = t + 1;
      const term = Math.pow(1 + guess, year);
      npv += cashFlows[t] / term;
      derivativeNpv -= (year * cashFlows[t]) / (term * (1 + guess));
    }

    const newGuess = guess - npv / derivativeNpv;
    if (Math.abs(newGuess - guess) < precision) {
      return newGuess * 100;
    }
    guess = newGuess;
  }
  return 0;
};

export const generateTableData = (
  initialInvestment: number, 
  cashFlows: number[], 
  rate: number
): YearlyData[] => {
  const totalYears = cashFlows.length;
  
  // Year 0
  const year0: YearlyData = {
    year: 0,
    cashFlow: initialInvestment,
    pv: initialInvestment,
    fv: initialInvestment * Math.pow(1 + rate, totalYears) // Conceptual FV of investment if held
  };

  const yearlyData: YearlyData[] = cashFlows.map((cf, index) => {
    const year = index + 1;
    return {
      year,
      cashFlow: cf,
      pv: calculatePV(cf, rate, year),
      fv: calculateFV(cf, rate, totalYears - year)
    };
  });

  return [year0, ...yearlyData];
};