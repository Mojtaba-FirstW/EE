import React from 'react';
import { LucideIcon } from 'lucide-react';

interface DashboardCardProps {
  title: string;
  value: string;
  subValue?: string;
  icon: LucideIcon;
  trend?: 'up' | 'down' | 'neutral';
  colorClass?: string; // We'll interpret this as bg color for the icon in doodle mode
}

export const DashboardCard: React.FC<DashboardCardProps> = ({ 
  title, 
  value, 
  subValue, 
  icon: Icon,
  trend = 'neutral',
  colorClass = 'bg-marker-yellow' // Default marker color
}) => {
  return (
    <div className={`doodle-card p-6 h-full flex flex-col justify-between`}>
      <div className="flex items-start justify-between mb-4">
        <h3 className="text-ink text-lg font-bold -rotate-1">{title}</h3>
        <div className={`p-3 ${colorClass} border-2 border-black rounded-lg shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] -rotate-3 group-hover:rotate-3 transition-transform`}>
          <Icon size={24} className="text-black" strokeWidth={2.5} />
        </div>
      </div>
      <div className="flex flex-col gap-1">
        <span className="text-3xl font-bold text-black tracking-wide">{value}</span>
        {subValue && (
          <span className={`text-sm font-bold px-2 py-0.5 rounded border border-black inline-block w-max ${
            trend === 'up' ? 'bg-marker-green text-black' : 
            trend === 'down' ? 'bg-marker-pink text-black' : 'bg-gray-200 text-gray-600'
          }`}>
            {subValue}
          </span>
        )}
      </div>
    </div>
  );
};